//Yuliya Kizelbasheva
//Project 7
//Nov 19, 2021

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class LoadRoster {
    public static void main(String[] args) {
        // Define local variables.
        Connection c = null;
        Statement s = null;
        Scanner fromFile = null;
        String sql1 = null, sql2 = null;
        String line = null, name = null, country = null, city = null, language = null, year = null;
        String[ ] fields;


        try {
            // Define Connection and Statement objects.
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:roster2.db");
            s = c.createStatement();

            // Instantiate scanner to read from file.
            fromFile = new Scanner(new File ("roster.txt"));

            // Create roster table.
            sql1 = "create table if not exists " +
                    "roster(rosterid integer, " +
                    "name varchar(10), " +
                    "country varchar(10), " +
                    "city varchar(10), " +
                    "language varchar(10), " +
                    "year varchar(10));";
            System.out.println("sql1: " + sql1);
            s.executeUpdate(sql1);

            // Read and throw away header line.
            fromFile.nextLine( );

            // Populate roster table.
            for (int id = 1; fromFile.hasNextLine( ); id++) {
                line = fromFile.nextLine( );
                fields = line.split(" ");
                name = fields[0].trim( );
                country = fields[1].trim( );
                city = fields[2].trim( );
                language = fields[3].trim( );
                year = fields[4].trim( );
                sql2 = String.format(
                        "insert into roster (rosterid, name,  country, city, language, year) " +
                                "values (%d, '%s', '%s', '%s', '%s', '%s');",
                        id, name, country, city, language, year);
                System.out.println(sql2);
                s.executeUpdate(sql2);
            }

            // Close Connection
            c.close( );
        }

        //Exceptions
        catch (FileNotFoundException e) {
            System.out.println("File queries.sql not found.");
            System.err.println( e.getClass( ).getName( ) +
                    ": " + e.getMessage( ) );
        }
        catch(SQLException e) {
            System.out.println("SQLException.");
            System.err.println( e.getClass( ).getName( ) +
                    ": " + e.getMessage( ) );
        }
        catch (ClassNotFoundException e ) {
            System.err.println( e.getClass().getName( ) +
                    ": " + e.getMessage( ));
        }
        finally {
            fromFile.close( );
        }
    }
}