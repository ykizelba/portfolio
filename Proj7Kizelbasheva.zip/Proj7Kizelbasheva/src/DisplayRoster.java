//Yuliya Kizelbasheva
//Project 7
//Nov 19, 2021

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class DisplayRoster {
    public static void main(String[] args) {
        // Declare local variables.
        Connection c = null;
        Statement s = null;
        ResultSet rs = null;
        int id = 0;
        String sql = null, name = null, country = null, city = null, language = null, year = null;
        try (Scanner fromKeyboard = new Scanner(System.in)) {
            // Define Connection and Statement objects.
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:roster2.db");
            s = c.createStatement();

            while (id != -1) {
                // Read id and display corresponding table row.
                System.out.print("Enter desired id: ");
                id = fromKeyboard.nextInt();
                sql = "select name, country, city, language, year from roster " + "where rosterid = " + id + ";";
                System.out.println(sql);
                rs = s.executeQuery(sql);
                while (rs.next()) {
                    name = rs.getString("name");
                    country = rs.getString("country");
                    city = rs.getString("city");
                    language = rs.getString("language");
                    year = rs.getString("year");
                    System.out.println("Name: " + name);
                    System.out.println("Country: " + country);
                    System.out.println("City: " + city);
                    System.out.println("Language: " + language);
                    System.out.println("Year: " + year);
                }
            }
        } catch (SQLException e) {
            System.out.println("SQLException.");
            System.err.println(e.getClass().getName() +
                    ": " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.err.println(e.getClass().getName() +
                    ": " + e.getMessage());
        }
    }
}