//Yuliya Kizelbasheva
//Project 7
//Nov 19, 2021

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
public class CreateTable {
    public static void main(String[] args) {
        // Define local variables.
        Connection c = null;
        Statement s = null;
        String sql1 = null, sql2 = null;

        try {
            // Define Connection and Statement objects.
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection(
                    "jdbc:sqlite:roster1.db");
            s = c.createStatement();

            // Create roster table.
            sql1 = "create table if not exists " +
                    "roster(name varchar(10), " +
                    "country varchar(10), " +
                    "city varchar(10), " +
                    "language varchar(10), " +
                    "year varchar(10));";
            System.out.println("sql1: " + sql1);
            s.executeUpdate(sql1);

            // Populate roster table.
            sql2 = "insert into roster (name, country, city, language, year) " +
                    "values('Hannah', 'UK', 'Beth', 'English', 'freshman');\n" +
                    "insert into roster (name, country, city, language, year) " +
                    "values('Layo', 'USA', 'Chicago', 'English', 'junior');\n" +
                    "insert into roster (name, country, city, language, year) " +
                    "values('Milana', 'Kazakhstan', 'Nur-Sultan', 'Russian', 'senior');\n";
            System.out.println("sql2:" + sql2);
            s.executeUpdate(sql2);

            // Close connection.
            c.close( );
        }

        //Exceptinos
        catch(SQLException e) {
            System.out.println("SQLException.");
            System.err.println( e.getClass( ).getName( ) +
                    ": " + e.getMessage( ) );
        }
        catch (ClassNotFoundException e ) {
            System.err.println( e.getClass( ).getName( ) +
                    ": " + e.getMessage( ));
        }
    }
}