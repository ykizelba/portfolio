//Yuliya Kizelbasheva
//Project 3a,
//May 5, 2022

// Source code file: MainActivity.java of StudentEntryForm example

package it372.ykizelbasheva.proj3kizelbasheva;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //initialize all variables

    private EditText edtFname;
    private Spinner spnColor;
    private RadioButton radCar1;
    private RadioButton radCar2;
    private RadioButton radYes;
    private RadioButton radNo;
    private CheckBox chkDisco;
    private TextView txtUserColor;
    private TextView txtUserCar;
    private TextView txtUserInt;
    private TextView txtCount;
    Integer count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // If there is a saved instance state, restore it.
        if (savedInstanceState != null) {
            count = savedInstanceState.getInt("count");
        }

        else {
            count = 0;
        }

        //assign the ids from the layouts

        setContentView(R.layout.activity_main);
        edtFname = findViewById(R.id.edt_Fname);
        spnColor = findViewById(R.id.spn_color);
        radCar1 = findViewById(R.id.rad_car1);
        radCar2 = findViewById(R.id.rad_car2);
        radYes = findViewById(R.id.rad_yes);
        radNo = findViewById(R.id.rad_no);
        txtUserColor = findViewById(R.id.txt_user_color);
        txtUserCar = findViewById(R.id.txt_user_car);
        txtUserInt = findViewById(R.id.txt_user_int);
        chkDisco = findViewById(R.id.chk_disco);
        // Uncomment the following line for testing.
        txtCount = findViewById(R.id.txt_count);

        txtCount.setText(String.valueOf(count));
    }

    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("count", count);
    }
    // Submit function

    public void submitInfo(View view) {

        count = count + 1;
        String text_count = getString(R.string.string_count) + count;
        txtCount.setText(text_count);

        String Fname =  edtFname.getText( ).toString( );
        String color =  spnColor.getSelectedItem( ).toString( );
        String car = radCar1.isChecked( ) ? "Coupe" : "Sports car";
        int price = 0;
        if (car == "Coupe") {
            price = 15000;
        }
        else if (car == "Sports car") {
            price = 70000;
        }
        String interior = radYes.isChecked( ) ? getString(R.string.interiorYes) : getString(R.string.interiorNo);

        if (interior == getString(R.string.interiorYes)) {
            price = price + 5000;
        }
        String disco = chkDisco.isChecked( ) ? getString(R.string.discountYes) : "";

        if (disco == getString(R.string.discoUserText)) {
            price = (int) (price * 0.9);
        }

        String text_price = getString(R.string.priceuserText) + price;

        String info = String.format("%s;%s;%s;%s;%s;%s",
                Fname, color, car, interior, disco, text_price);

        Intent intent = new Intent(this,
                ConfirmationActivity.class);
        intent.putExtra("info", info);
        startActivity(intent);

    }

    //Clear function

    public void resetInfo(View view) {

        if ( edtFname!= null) edtFname.setText("");
        radCar1.setChecked(false);
        radCar2.setChecked(false);
        radYes.setChecked(false);
        radNo.setChecked(false);
        chkDisco.setChecked(false);
        spnColor.setSelection(0);

    }

}