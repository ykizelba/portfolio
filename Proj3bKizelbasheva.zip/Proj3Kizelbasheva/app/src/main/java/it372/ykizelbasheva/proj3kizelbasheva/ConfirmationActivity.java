//Yuliya Kizelbasheva
//Project 3a,
//May 5, 2022


// Source code file: ConfirmationActivity.java of StudentEntryForm example

package it372.ykizelbasheva.proj3kizelbasheva;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ConfirmationActivity extends AppCompatActivity {
    private TextView txtFname;
    private TextView txtColor;
    private TextView txtCar;
    private TextView txtInt;
    private TextView txtDisco;
    private TextView txtPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        // crating an array with all the values

        Intent intent = getIntent( );
        String info = intent.getStringExtra("info");
        String[ ] fields = info.split(";");
        String Fname = fields[0];
        String color = fields[1];
        String car = fields[2];
        String interior = fields[3];
        String disco = fields[4];
        String text_price = fields[5];
        txtFname = findViewById(R.id.txt_Fname);
        txtColor = findViewById(R.id.txt_color);
        txtCar = findViewById(R.id.txt_car);
        txtInt = findViewById(R.id.txt_int);
        txtDisco = findViewById(R.id.txt_disco);
        txtPrice = findViewById(R.id.txt_price);
        txtFname.setText("Thank you, " + Fname + ", for your order!");
        txtColor.setText("Car Color: " + color);
        txtCar.setText("Car Type: " + car);
        txtInt.setText("Leather interior will " + interior);
        txtDisco.setText(disco);
        txtPrice.setText(text_price);
    }
}