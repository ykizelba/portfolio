//Yuliya Kizelbasheva
//Project 2
//Apr 19, 2022

package it372.ykizelbasheva.proj2kizelbasheva;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View view) {
        //initialising variables and fiding views by IDs
        EditText princ = findViewById(R.id.p);
        EditText iRate = findViewById(R.id.ir);
        EditText term = findViewById(R.id.t);

        TextView monthP = findViewById(R.id.mp);

        //initialise the variables and assigning the values
        // from user inputs to those variables
        int p;
        p = 0;
        int ir = 0;
        int t = 0;
        String i1 = princ.getText().toString();
        String i2 = iRate.getText( ).toString( );
        String i3 = term.getText( ).toString( );

        try {
            //calculating the monthly payment
            p = Integer.parseInt(i1);
            ir = Integer.parseInt(i2);
            t = Integer.parseInt(i3);

            double mp = (p * ir / 1200.0) / ( 1 -  Math.pow( 1.0 + (ir / 1200.0), 12 * -t));
            monthP.setText(String.valueOf(mp));
        }
        //in case of invalid input
        catch(NumberFormatException e) {
            monthP.setText("PLEASE ENTER ONLY INTEGERS");
        }
    }
}
