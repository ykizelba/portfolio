package it372.ykizelbasheva.proj4kizelbasheva;

//Yuliya Kizelbasheva
//Project 4,
//May 27, 2022

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RadioButton;
import android.widget.CheckBox;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;


public class MyView extends View {

    public ArrayList<Point> points;

    public ArrayList<Point> points1;

    private String checkY;

//    private Integer radius;

    public MyView(Context context) {
        super(context);

        points = new ArrayList<Point>();
        points1 = new ArrayList<Point>();


        this.setBackgroundColor(
                Color.parseColor("#1b1e23"));
        this.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    int x = (int) e.getX();
                    int y = (int) e.getY();
                    if (checkY == "y"){
                    points.add(new Point(x, y));
                    }
                    else {
                    points1.add(new Point(x, y));
                    }
                    MyView.this.invalidate();
                }
                // System.out.println("x=" + x + " y=" + y);
                return true;
            }

        });

    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    // clear the user drawing
    public void reset() {
        points.clear();
        points1.clear();
        this.invalidate();
    }

    // function for a checkbox
    public void setCh(String checkY) {
        this.checkY = checkY;
    }

    /*public void changeR(Integer radius) {
        this.radius = radius;
    }*/


    @Override
    public void onDraw(Canvas c) {
        super.onDraw(c);

        //drawings by user if they selected checkbox
        for (Point p : points)
        {
                Paint paint1 = new Paint();
                paint1.setColor(Color.YELLOW);
                c.drawCircle(p.getX(), p.getY(), 90, paint1);
        }
        //drawings by user if they did not select checkbox
        for (Point s: points1){
                Paint paint2 = new Paint();
                paint2.setColor(Color.BLUE);
                c.drawCircle(s.getX(), s.getY(), 40, paint2);

        }


        //Draw cracks
        Paint paint = new Paint();
        paint.setColor(Color.YELLOW);

        float prevx = 0.0f;
        float prevy = 0.0f;

        //Get crack data points
        InputStream is = getResources().openRawResource(R.raw.cracks);
        Scanner s = new Scanner(is);
        s.nextLine();

        //Draw a crack
        while (s.hasNextLine()) {
            String line = s.nextLine();
            String[] fields = line.split(",");
            float x = 30.0f * Float.parseFloat(fields[0]);
            float y = 30.0f * Float.parseFloat(fields[1]);

            int startPoint = Integer.parseInt(fields[2]);
            if (startPoint == 0) {
                c.drawLine(prevx, prevy, x, y, paint);
            }
            prevx = x;
            prevy = y;

        }
        s.close();
    }
}

