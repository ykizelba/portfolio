package it372.ykizelbasheva.proj4kizelbasheva;

//Yuliya Kizelbasheva
//Project 4,
//May 27, 2022

// DrawStar Example
// Source code file: MainActivity.java
// Add MyView widget to the layout.
// This widget draws a five-pointed star.
// DrawEx3 Example
// Source code file: MainActivity.java

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    MyView mv;

    private CheckBox ch1;

    //private SeekBar seekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*seekBar = findViewById(R.id.sb);
        seekBar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener( ) {
                    @Override
                    public void onProgressChanged(SeekBar seekBar,
                                                  int i, boolean b) {
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) { }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) { }
                });*/

        // Create a view object and add it to the layout.
        LinearLayout layout = findViewById(R.id.linear_layout);
        mv = new MyView(this);
        layout.addView(mv);

        ch1 = findViewById(R.id.chkYellow);
    }

    //clear the drawing
    public void reset (View view) {
        mv.reset();
    }

    //when the user clicks checkbox
    public void onClick(View view) {

        String checkY = ch1.isChecked()? "y":"n";
        mv.setCh(checkY);
        mv.invalidate( );
    }

    /*public void onS (View view) {
        int radius = seekBar.getProgress( );
        mv.changeR(radius);
        mv.invalidate( );
    }*/





}